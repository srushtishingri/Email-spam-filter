"use server"

// Simple spam detection algorithm
export async function checkSpam(content: string) {
  // Convert to lowercase for case-insensitive matching
  const text = content.toLowerCase()

  // Define spam indicators with their weights
  const spamIndicators = [
    { pattern: /\b(viagra|cialis|pharmacy)\b/g, weight: 0.8, reason: "Contains pharmaceutical terms" },
    { pattern: /\b(casino|lottery|jackpot|prize|winner)\b/g, weight: 0.6, reason: "Contains gambling terms" },
    { pattern: /\b(free|discount|save|offer|deal|limited time)\b/g, weight: 0.3, reason: "Contains promotional terms" },
    { pattern: /\b(urgent|immediate|act now|don't delay)\b/g, weight: 0.5, reason: "Contains urgency terms" },
    { pattern: /\$([\d,]+)/g, weight: 0.4, reason: "Contains dollar amounts" },
    { pattern: /\b(million|billion)\b/g, weight: 0.5, reason: "Contains large monetary references" },
    { pattern: /\b(click here|visit now)\b/g, weight: 0.4, reason: "Contains call-to-action phrases" },
    {
      pattern: /\b(password|account|verify|confirm|update)\b/g,
      weight: 0.6,
      reason: "Contains account verification terms",
    },
    { pattern: /\b(investment|stock|forex|crypto|bitcoin)\b/g, weight: 0.7, reason: "Contains investment terms" },
    { pattern: /![!?]{2,}/g, weight: 0.3, reason: "Contains excessive punctuation" },
    { pattern: /\b[A-Z\s]{10,}\b/g, weight: 0.4, reason: "Contains all caps text" },
  ]

  // Legitimate content indicators (reduce spam score)
  const legitimateIndicators = [
    { pattern: /\b(meeting|agenda|report|project|team)\b/g, weight: -0.3, reason: "Contains business terms" },
    { pattern: /\b(regards|sincerely|thank you)\b/g, weight: -0.2, reason: "Contains formal closing" },
    { pattern: /\b(invoice|receipt|order|shipping|delivery)\b/g, weight: -0.2, reason: "Contains transaction terms" },
  ]

  let score = 0
  const reasons: string[] = []

  // Check for spam indicators
  for (const indicator of spamIndicators) {
    const matches = text.match(indicator.pattern)
    if (matches && matches.length > 0) {
      score += indicator.weight * Math.min(matches.length, 3) // Cap the impact
      reasons.push(indicator.reason)
    }
  }

  // Check for legitimate indicators
  for (const indicator of legitimateIndicators) {
    const matches = text.match(indicator.pattern)
    if (matches && matches.length > 0) {
      score += indicator.weight * Math.min(matches.length, 3) // Cap the impact
    }
  }

  // Additional heuristics

  // Check for image-to-text ratio (approximated by checking for HTML img tags)
  const imgTags = (text.match(/<img/g) || []).length
  if (imgTags > 3) {
    score += 0.4
    reasons.push("Contains many images")
  }

  // Check for links
  const links = (text.match(/https?:\/\//g) || []).length
  if (links > 2) {
    score += 0.3 * Math.min(links, 5)
    reasons.push("Contains multiple links")
  }

  // Check for suspicious TLDs
  if (/(\.info|\.xyz|\.top|\.club)\b/i.test(text)) {
    score += 0.5
    reasons.push("Contains suspicious domain extensions")
  }

  // Check for misspelled domains of popular services
  if (/(paypa[^l]|amaz[^o]n|netfl[^i]x|facebo[^o]k|googl[^e])/i.test(text)) {
    score += 0.8
    reasons.push("Contains misspelled popular domain names")
  }

  // Normalize score to be between 0 and 1
  score = Math.max(0, Math.min(1, score))

  // Determine if it's spam based on threshold
  const isSpam = score > 0.5

  // Simulate processing delay for realism
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return {
    isSpam,
    score,
    reasons: [...new Set(reasons)], // Remove duplicate reasons
  }
}
