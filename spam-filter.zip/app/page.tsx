import { SpamFilterForm } from "@/components/spam-filter-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold text-center mb-8">Email Spam Filter</h1>
      <div className="max-w-3xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Check Email Content</CardTitle>
            <CardDescription>Enter email content to analyze whether it's likely to be spam or not.</CardDescription>
          </CardHeader>
          <CardContent>
            <SpamFilterForm />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
