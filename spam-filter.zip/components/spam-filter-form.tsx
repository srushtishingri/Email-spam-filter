"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { checkSpam } from "@/app/actions"
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function SpamFilterForm() {
  const [emailContent, setEmailContent] = useState("")
  const [result, setResult] = useState<{ isSpam: boolean; score: number; reasons: string[] } | null>(null)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const spamResult = await checkSpam(emailContent)
      setResult(spamResult)
    } catch (error) {
      console.error("Error checking spam:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Textarea
          placeholder="Paste email content here..."
          className="min-h-[200px]"
          value={emailContent}
          onChange={(e) => setEmailContent(e.target.value)}
          required
        />
      </div>

      <Button type="submit" className="w-full" disabled={loading || !emailContent.trim()}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Analyzing...
          </>
        ) : (
          "Check for Spam"
        )}
      </Button>

      {result && (
        <Alert variant={result.isSpam ? "destructive" : "default"} className="mt-4">
          {result.isSpam ? <AlertCircle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
          <AlertTitle>{result.isSpam ? "Likely Spam" : "Likely Not Spam"}</AlertTitle>
          <AlertDescription>
            <div className="mt-2">
              <p>Spam Score: {result.score.toFixed(2)}</p>
              {result.reasons.length > 0 && (
                <div className="mt-2">
                  <p className="font-medium">Reasons:</p>
                  <ul className="list-disc pl-5 mt-1 text-sm">
                    {result.reasons.map((reason, index) => (
                      <li key={index}>{reason}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </AlertDescription>
        </Alert>
      )}
    </form>
  )
}
